Homework 1

Student: 
	b99202064

Environment:
	ubuntu 14.04 64bit
	g++

Main File:
	hw1.cpp

Test File:
	vector-vector product : vv.txt
	matrix-vector product : mv.txt
	matrix-matrix product : mm.txt

Execute:
	compile: make
	run: make run

Remark:
	filename is without the extension when reading by program (default using .txt)

Result:
	mm_result.txt
	mv_result.txt
	vv_result.txt